﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace App4
{
    [Table("ЗаявкиНаПоступления")]
    public class Заявка
    {
        [PrimaryKey, AutoIncrement, Column("_id")]
        public int Id_Zayavki { get; set; }
        public string Фамилия_ЗК { get; set; }
        public string Имя_ЗК { get; set; }
        public string Отчество_ЗК { get; set; }
        public string ФИО_Ребенка { get; set; }
        public string ДатаИМестоРождения { get; set; }
        public string МестоЖительства { get; set; }
        public string Снисл { get; set; }
        public string ГруппаЗдоровья { get; set; }
        public string ДанныеПаспорта { get; set; }
        public string Класс { get; set; }
        public string ДатаОбучения { get; set; }
        public string ФИО_Мать { get; set; }
        public string МестоЖительстваМать { get; set; }
        public string КонтактыМать { get; set; }
        public string ФИО_Отец { get; set; }
        public string МестоЖительстваОтец { get; set; }
        public string КонтактыОтец { get; set; }
    }
}
