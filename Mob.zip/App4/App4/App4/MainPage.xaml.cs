﻿using System;
using Xamarin.Forms;

namespace App4
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();

        }
        protected override void OnAppearing()
        {
            requestsList.ItemsSource = App.Database.GetItems();
            base.OnAppearing();
        }
        // обработка нажатия элемента в списке
        private async void OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            Заявка selected = (Заявка)e.SelectedItem;
            Page1 Page = new Page1();
            Page.BindingContext = selected;
            await Navigation.PushAsync(Page);
        }
        // обработка нажатия кнопки добавления
        private async void CreateFriend(object sender, EventArgs e)
        {
            Заявка requests = new Заявка();
            Page1 friend = new Page1();
            friend.BindingContext = requests;
            await Navigation.PushAsync(friend);
        }
    }
}