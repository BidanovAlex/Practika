﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace App4
{

    public partial class Page1 : ContentPage
    {

        public Page1()
        {
            InitializeComponent();

        }
        private void SaveFriend(object sender, EventArgs e)
        {
            var requests = (Заявка)BindingContext;
            if (!String.IsNullOrEmpty(requests.ФИО_Ребенка))
            {
                App.Database.SaveItem(requests);
            }
            this.Navigation.PopAsync();
        }

       

        private void DeletRequests(object sender, EventArgs e)
        {
            var friend = (Заявка)BindingContext;
            App.Database.DeleteItem(friend.Id_Zayavki);
            this.Navigation.PopAsync();
        }
    }
}