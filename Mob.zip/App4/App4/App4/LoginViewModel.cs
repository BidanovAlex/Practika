﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Xamarin.Forms;

namespace App4
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private User _user;
        public User User
        {
            get { return _user; }
            set
            {
                _user = value;
                OnPropertyChanged();
            }
        }

        public Command LogInCommand { get; }
        public Command SignUpCommand { get; }

        public LoginViewModel()
        {
            User = new User();
            LogInCommand = new Command(OnLogInButtonClicked);
            SignUpCommand = new Command(OnSignUpButtonClicked);
        }

        // метод для логина
        private async void OnLogInButtonClicked()
        {
            var database = new UserDatabase(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "users.db3"));

            var usersList = await database.GetUsersAsync();
            var validUser = usersList.FirstOrDefault(u => u.Username == User.Username && u.Password == User.Password);

            if (validUser != null)
            {
                // сохранение данных сессии и переход на главную страницу приложения
                await Application.Current.MainPage.Navigation.PushAsync(new MainPage());
            }
            else
            {
                await Application.Current.MainPage.DisplayAlert("Ошибка", "Неверное имя пользователя или пароль", "OK");
            }
        }

        // метод для перехода на страницу регистрации
        private async void OnSignUpButtonClicked()
        {
            await Application.Current.MainPage.Navigation.PushAsync(new SignUpPage());
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}