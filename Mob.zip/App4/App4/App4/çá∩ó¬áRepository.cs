﻿using System;
using System.Collections.Generic;
using SQLite;

namespace App4
{
    public class ЗаявкаRepository
    {
        SQLiteConnection database;
        public ЗаявкаRepository(string databasePath)
        {
            database = new SQLiteConnection(databasePath);
            database.CreateTable<Заявка>();
        }

       
        public IEnumerable<Заявка> GetItems()
        {
            return database.Table<Заявка>().ToList();
        }
        public Заявка GetItem(int id)
        {
            return database.Get<Заявка>(id);
        }
        public int DeleteItem(int id)
        {
            return database.Delete<Заявка>(id);
        }
        public int SaveItem(Заявка item)
        {
            if (item.Id_Zayavki != 0)
            {
                database.Update(item);
                return item.Id_Zayavki;
            }
            else
            {
                return database.Insert(item);
            }
        }
    }
}