﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prilojenie
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var dannie = new Данные();
            using (var db = new PracticeEntities1())
            {
                dannie.ФИО_Родителя = Fam1.Text + Name1.Text + Otch1.Text;
                dannie.ФИО_Ребенка = ФИО_Ребенка.Text;
                dannie.ДатаИМестоРождения = ДатаИМестоРождения.Text;
                dannie.МестоЖительства = МестоЖительства.Text;
                dannie.Класс = Класс.Text;
                dannie.ДатаОбучения = ДатаОбучения.Text;
                dannie.ФИО_Мать = ФИО_Мать.Text;
                dannie.МестоЖительстваМать = МестоЖительстваМать.Text;
                dannie.КонтактыМать = КонтактыМать.Text;
                dannie.ФИО_Отец = ФИО_Отец.Text;
                dannie.МестоЖительстваОтец = МестоЖительстваОтец.Text;
                dannie.КонтактыОтец = КонтактыОтец.Text;
                db.Данные.Add(dannie);
                db.SaveChanges();
                MessageBox.Show("Заявка отправлена, ожидайте звонка");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Forma1 forma = new Forma1();
            forma.Show();
            this.Close();
        }
    }
}
