﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prilojenie
{
    /// <summary>
    /// Логика взаимодействия для Forma1.xaml
    /// </summary>
    public partial class Forma1 : Window
    {
        public Forma1()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var log = Login.Text;
            var pas = Password.Password;
            using (var db = new PracticeEntities1())
            {
                var user = db.User.FirstOrDefault(s => s.Login == log && s.Password == pas);
                if (user != null && user.IDRole == 1)
                {
                    MainForm MW = new MainForm();
                    MW.Show();
                    this.Close();
                    MessageBox.Show("Приветствую вас: Администратор");
                }
                else if (user != null && user.IDRole == 2)
                {
                    MainWindow userForm = new MainWindow();
                    userForm.Show();
                    this.Close();
                    MessageBox.Show("Приветствую вас: Пользователь");
                }
                else
                {
                    MessageBox.Show("Ошибка логина и/или пароля");
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Reg reg = new Reg();
            reg.Show();
            this.Close();
        }
    }
}
