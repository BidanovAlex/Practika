﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Prilojenie
{
    public class Test
    {
        public bool Login(string login, string password)
        {
            if (login == "admin" && password == "admin")
            {
                return true;
            }
            return false;
        }
    }
}
