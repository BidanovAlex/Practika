﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prilojenie
{
    /// <summary>
    /// Логика взаимодействия для Reg.xaml
    /// </summary>
    public partial class Reg : Window
    {
        public Reg()
        {
            InitializeComponent();
        }

       

        private void Reg_Click(object sender, RoutedEventArgs e)
        {
            var user = new User();

            using (var db = new PracticeEntities1())
            {
                user.Login = Login.Text;
                user.Password = Password.Password;
                user.IDRole = 2;
                db.User.Add(user);
                db.SaveChanges();
                Forma1 forma = new Forma1();
                forma.Show();
                this.Close();
            }
        }
    }
}
