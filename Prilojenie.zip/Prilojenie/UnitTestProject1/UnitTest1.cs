﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Prilojenie;

namespace UnitTestProject1
{
    [TestClass]
    public class Check
    {
        [TestMethod]

        public void CheckLogin()
        {
            var log = new Test();
            bool ex = true;
            bool result = log.Login("admin", "admin");
            Assert.AreEqual(ex, result);
        }
    }
}
